module.exports = {
  printWidth: 100,
  useTabs: false,
  trailingComma: 'es5',
  tabWidth: 2,
  semi: true,
  singleQuote: true,
  bracketSpacing: true,
  jsxBracketSameLine: true,
  endOfLine: 'lf',
  arrowParens: 'always',
};
